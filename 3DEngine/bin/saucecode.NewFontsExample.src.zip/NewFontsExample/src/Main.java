import java.awt.Font;
import java.io.File;

import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;

import tools.Color4f;
import tools.FontTT;
import tools.Texture;
import tools.TextureLoader;


public class Main {

	public static void main(String[] args) throws LWJGLException {
		Display.setDisplayMode(new DisplayMode(1280,720));
		Display.create();
		
		initGL2();
		init();
		
		while(!Display.isCloseRequested()){
			GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
			GL11.glLoadIdentity();
			
			render();
			
			Display.update();
			Display.sync(60);
		}
		
		Display.destroy();
		System.exit(0);
	}

	static FontTT myFont;
	static Texture myTexture;
	
	private static void initGL2() {
		// setup the 2D view
		GL11.glMatrixMode(GL11.GL_PROJECTION);
		GL11.glLoadIdentity();
		GL11.glOrtho(0, 1280, 0, 720, -1, 1);
		GL11.glMatrixMode(GL11.GL_MODELVIEW);
		GL11.glLoadIdentity();
		
		// set up textures + transparency
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		GL11.glEnable(GL11.GL_ALPHA);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
	}

	private static void init() {
		// Load resources!
		TextureLoader loader = new TextureLoader();
		try{
			myTexture = loader.getTexture("dogs.jpg", false); // load texture
			
			int fontResolution = 16; // larger number = better quality = more RAM required
			myFont = new FontTT(Font.createFont(Font.TRUETYPE_FONT, new File("kenvector_future.ttf")), fontResolution, 0);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	private static void render() {
		// draw things
		GL11.glColor3f(1, 1, 1);
		myTexture.bind(); // use the texture
		drawQuad(0,0, 480,480); // draw a square
		
		// draw some text
		myFont.drawText("hello, world!", 22, 20, 680, 0, Color4f.YELLOW, 0, 0, 0, false);
		myFont.drawText("here is some centered text!", 22, Display.getWidth()/2f, 680, 0, new Color4f(0.3f, 0.3f, 1.0f), 0, 0, 0, true);
	}
	
	public static void drawQuad(float x1, float y1, float x2, float y2){
		GL11.glBegin(GL11.GL_QUADS);
		GL11.glTexCoord2f(0, 0);
		GL11.glVertex2f(x1, y1);
		GL11.glTexCoord2f(1, 0);
		GL11.glVertex2f(x2, y1);
		GL11.glTexCoord2f(1, 1);
		GL11.glVertex2f(x2, y2);
		GL11.glTexCoord2f(0, 1);
		GL11.glVertex2f(x1, y2);
		GL11.glEnd();
	}
}
